package wheelofjeopardy.widgets;

import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.Timer;

public class BlinkingBorderLabel extends JLabel {

    private static int alpha = 255;
    private static int increment = -5;
    private final static int red = 139;
    private final static int green = 216;
    private final static int blue = 189;

    private final Timer blinkingTimer = new Timer(5, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            alpha += increment;
            if (alpha >= 255) {
                alpha = 255;
                increment = -increment;
            }
            if (alpha <= 0) {
                alpha = 0;
                increment = -increment;
            }
            setBorder(BorderFactory.createLineBorder(new Color(red, green, blue, alpha), 3));
        }
    });
    
    private final MouseAdapter ma = new MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                blinkingTimer.start();
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                blinkingTimer.stop();
                setBorder(null);
            }
    };

    public BlinkingBorderLabel() {
        super();
        addMouseListener(ma);
    }
}
