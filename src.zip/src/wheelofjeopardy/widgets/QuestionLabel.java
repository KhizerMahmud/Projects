/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wheelofjeopardy.widgets;

import wheelofjeopardy.view.MainFrame;
import wheelofjeopardy.view.AnswerQuestionDialog;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.Timer;
import wheelofjeopardy.config.JeopardyQuestion;

/**
 *
 * @author alissachiu
 */
public class QuestionLabel extends JLabel {
    int value;
    JeopardyQuestion question;
    boolean answered;
    
    private static int alpha = 255;
    private static int increment = -5;
    private final static int red = 255;
    private final static int green = 255;
    private final static int blue = 255;
    
    private final Timer blinkingTimer = new Timer(5, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            alpha += increment;
            if (alpha >= 255) {
                alpha = 255;
                increment = -increment;
            }
            if (alpha <= 0) {
                alpha = 0;
                increment = -increment;
            }
            setBorder(BorderFactory.createLineBorder(new Color(red, green, blue, alpha), 3));
        }
    });
    
    private final MouseAdapter ma = new MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                // FIXME/TODO: these should light up when the question is selected next by the wheel instead,
                // not by mouse hovering
                blinkingTimer.start();
                setBackground(new java.awt.Color(12, 31, 204));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                blinkingTimer.stop();
                setBorder(null);
                setBackground(new java.awt.Color(7, 18, 119));
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                System.out.println(question.getQuestion());
                System.out.println(question.getCorrectAnswer());
                AnswerQuestionDialog dialog = new AnswerQuestionDialog(MainFrame.getInstance(), question);
            }
    };
    
    public QuestionLabel() {
        super();
        value = 0;
        question = new JeopardyQuestion();
        answered = true;
        
        addMouseListener(ma);
        //setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        setMaximumSize(new java.awt.Dimension(100, 70));
        setMinimumSize(new java.awt.Dimension(100, 70));
        setPreferredSize(new java.awt.Dimension(100, 70));
        setBackground(new java.awt.Color(7, 18, 119));
        setFont(new java.awt.Font("Arial Narrow", 1, 40));
        setForeground(new java.awt.Color(214, 159, 76));
        setOpaque(true);
    }
    
    public void setValue(int value) {
        setText("$" + String.valueOf(value));
    }
    
    public void setQuestion(JeopardyQuestion question) {
        this.question = question;
        setValue(question.getValue());
    }
    
    public void setAnswered(boolean answered) {
        this.answered = answered;
        if (answered) {
            removeMouseListener(ma);
            setText("");
            setBackground(new java.awt.Color(7, 18, 119));
        }
    }
    
    public int getValue() {
        return value;
    }
    
    public JeopardyQuestion getQuestion() {
        return question;
    }
    
    public boolean getAnswered() {
        return answered;
    }
}
