/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wheelofjeopardy.model;

/**
 *
 * @author alissachiu
 */
public class Player {
    private static String name;
    private static int score;
    
    public Player() {
        name = new String();
        score = 0;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public void setScore(int score) {
        this.score = score;
    }
}
