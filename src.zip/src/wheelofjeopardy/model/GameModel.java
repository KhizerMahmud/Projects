/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wheelofjeopardy.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import wheelofjeopardy.config.Category;
import wheelofjeopardy.config.QuestionFileUtil;

/**
 *
 * @author alissachiu
 */
public class GameModel extends Observable {
    private static GameModel INSTANCE = null;
    private static List<Player> playerList;
    private static final int NUM_WHEEL_SPINS = 50;
    private static int remainingSpins;
    private static final int NUM_ROUNDS = 2;
    private static int currentRound;
    private static int currentPlayerIndex;
    private static Player currentPlayer;
    private static List<Category> firstRoundQuestions;
    private static List<String> wheelSectors;
    
    public GameModel() {
        INSTANCE = this;
        playerList = new ArrayList<>();
        currentPlayerIndex = 0;
        currentPlayer = new Player();
        currentRound = 1;
        remainingSpins = NUM_WHEEL_SPINS;
        firstRoundQuestions = QuestionFileUtil.getInstance().getCategoryGroups();
        wheelSectors = new ArrayList<>();
        
        sendUpdate();
    }
    
    private void sendUpdate() {
        setChanged();
        notifyObservers();
    }
    
    public static GameModel getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new GameModel();
        }
        return INSTANCE;
    }
    
    public List<Category> getQuestions() {
        return firstRoundQuestions;
    }
    
    public void resetGameState() {
        INSTANCE = null;
    }
    
    public void setQuestions(List<Category> questions) {
        this.firstRoundQuestions = questions;
        sendUpdate();
    }
    
    public void setPlayers(List<Player> playerList) {
        this.playerList = playerList;
    }
    
    public void setNextPlayer() {
        currentPlayerIndex++;
        currentPlayerIndex = currentPlayerIndex % playerList.size();
        currentPlayer = playerList.get(currentPlayerIndex);
        sendUpdate();
    }
    
    public void setPlayerScore(int playerIndex, int score) {
        if (playerIndex >= 0 && playerIndex < playerList.size()) {
            playerList.get(playerIndex).setScore(score);
            sendUpdate();
        }
    }
}
