package wheelofjeopardy.wheel;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.geom.Point2D;
import java.util.List;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JPanel;
import wheelofjeopardy.model.GameModel;
import wheelofjeopardy.config.Category;

public class Wheel extends JPanel {

    Image _image = null;
    private double _delta;
    private Point2D _imagePosition;
    private Point2D _rotationCenter;
    private double _rotationAngle = 0;

    private List<Color> _colors;
    int _colorCounter = 0;

    private final int BORDER = 10;
    private int _radius;
    private Point2D _center = new Point2D.Double();

    List<String> _stringList;
    private int _noElem;
    private final int LIMIT = 100;
    private final Font DEFAULTFONT = new Font("Arial Narrow", Font.PLAIN, 14);
    private final Font _font = DEFAULTFONT;

    private boolean _spinOnOff = false;
    private boolean buttonStopWheel = false;
    private final double _spinDeceleration = -300;
    private final int _refreshRate = 100;

    private static final double STARTING_SPIN_SPEED = 1000;

    public double getRotationAngle() {
        /*
		 * Get current rotation of the wheel.
         */
        return _rotationAngle;
    }

    public void setRotationAngle(double rotationAngle) {
        /*
		 * Set the current rotation of the wheel.
         */
        _rotationAngle = rotationAngle % 360;
        this.repaint();
    }

    public void setListOfStrings(List<String> list) {
        /*
		 * Set list of strings displayed inside the sections of the wheel.
		 * The initial list is set in constructor method and can be changed during runtime.
         */
        _noElem = list.size();
        if (_noElem > LIMIT) {
            return;
        }
        _delta = (double) 360 / (double) _noElem;
        _stringList = list;
        _image = null;
        _spinOnOff = false;
        setRotationAngle(0);
        this.repaint();
    }

    public boolean isSpinning() {
        /*
		 * Check if the wheel is spinning.
         */
        return _spinOnOff;
    }

    public String getSelectedString() {
        return _stringList.get((int) Math.floor(_noElem + (_rotationAngle % 360) / _delta) % _noElem);
    }

    public void startSpinning() {
        double initialSpeed = 1000;
        try {
            //spinStartAsync(Math.abs(initialSpeed), (int)Math.signum(initialSpeed), _spinDeceleration);
            SpinRunnable spinRunnable = new SpinRunnable();
            Thread t = new Thread(spinRunnable);
            t.start();
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }

    public void stopSpinning() {
        buttonStopWheel = true;
    }

    public List<String> getWheelSectors() {
        List<String> sectors = new ArrayList<>();
        sectors.add("LOSE A TURN");
        sectors.add("FREE TURN");
        sectors.add("BANKRUPT");
        sectors.add("PLAYER'S CHOICE");
        sectors.add("OPPONENTS' CHOICE");
        sectors.add("SPIN AGAIN");
        for (Category group : GameModel.getInstance().getQuestions()) {
            sectors.add(group.getCategory().toUpperCase());
            sectors.add(group.getCategory().toUpperCase());
        }
        Collections.shuffle(sectors);
        
        return sectors;
    }

    public Wheel() {
        setBackground(Color.BLACK);

        setListOfStrings(getWheelSectors());
    }

    @Override
    public void paintComponent(Graphics g) {
        /*
		 * Paintcomponent - if the image is null, create it and then draw it whilst keeping the current rotation.
		 * The image can be larger than the displaying area, so after it is drawn it needs to be placed properly.
         */
        super.paintComponent(g);

        if (_image == null) {
            _image = drawImage();
            _rotationCenter = new Point2D.Double(
                    this.getWidth() - _image.getWidth(null) + _center.getX(),
                    this.getHeight() / 2
            );
            _imagePosition = new Point2D.Double(
                    (int) (this.getWidth() - _image.getWidth(null)),
                    (int) (this.getHeight() / 2 - _center.getY())
            );
        }

        Graphics2D gPanel = (Graphics2D) g;
        gPanel.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        gPanel.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        gPanel.rotate(Math.toRadians(_rotationAngle), _rotationCenter.getX(), _rotationCenter.getY());
        gPanel.drawImage(_image, (int) _imagePosition.getX(), (int) _imagePosition.getY(), null);
    }

    private BufferedImage drawImage() {
        /*
		 * Calculate all the necessary parameters for the wheel and draw it section by section.
         */
        int width = this.getWidth(), height = this.getHeight();
        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = (Graphics2D) img.getGraphics();

        // Calculate radius
        _radius = Math.min(img.getWidth(), img.getHeight()) / 2 - BORDER;

        double stringDistanceFromEdge = 0.05 * _radius;
        int fontSize, stringWidth, maxStringWidth;

        maxStringWidth = (int) (_radius - 2 * stringDistanceFromEdge);
        //fontSize = calcFontSize(g2d, stringDistanceFromEdge, maxStringWidth);
        fontSize = _font.getSize();
        g2d.setFont(new Font(_font.getFamily(), _font.getStyle(), fontSize));

        // Calculate center point
        _center = new Point2D.Double((double) img.getWidth() / 2, (double) img.getHeight() / 2);

        // Set rendering hints
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.rotate(Math.toRadians(_rotationAngle), _center.getX(), _center.getY());

        // Divide circle and draw strings
        FontMetrics fontMetrics;
        if (_colors == null) {
            _colors = getDefaultColorList();
        }
        _colorCounter = 0;
        for (int i = _noElem - 1; i >= 0; i--) {
            // Fill section depending on the chosen shape
            g2d.setColor(_colors.get(_colorCounter++ % _colors.size()));
            fillArc(g2d);
            // Draw string - rotate half delta, then draw then rotate the other half (to have the string in the middle)
            g2d.rotate(Math.toRadians(_delta / 2), _center.getX(), _center.getY());
            g2d.setColor(Color.BLACK);
            fontMetrics = g2d.getFontMetrics();
            stringWidth = fontMetrics.stringWidth(_stringList.get(i));
            g2d.drawString(_stringList.get(i), (int) (_center.getX() + maxStringWidth - stringWidth + stringDistanceFromEdge), (int) (_center.getY() + (double) fontMetrics.getHeight() / 2 - fontMetrics.getMaxDescent()));
            g2d.rotate(Math.toRadians(_delta / 2), _center.getX(), _center.getY());
        }

        return img;
    }

    private void fillArc(Graphics g2d) {
        g2d.fillArc((int) _center.getX() - _radius, (int) _center.getY() - _radius, 2 * _radius, 2 * _radius, 0, (int) -Math.ceil(_delta)); // use ceil because of decimal part (would be left empty)
    }

    private class SpinRunnable implements Runnable {

        /*
		 * Runnable class that handles the spinning of the wheel.
		 * It sets the rotation angle by calculating the speed through time based on deceleration.
		 * Each setRotationAngle call will cause the wheel to be redrawn.
         */
        private double currSpinSpeed;

        public SpinRunnable() {
            currSpinSpeed = STARTING_SPIN_SPEED;
        }

        public void run() {
            _spinOnOff = true;
            int sleepTime = 1000 / _refreshRate;
            double delta;
            while (_spinOnOff && currSpinSpeed > 0) {
                delta = currSpinSpeed / _refreshRate;
                try {
                    Thread.sleep(sleepTime);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                setRotationAngle(getRotationAngle() + delta);
                if (buttonStopWheel) {
                    currSpinSpeed += _spinDeceleration / _refreshRate;
                }
            }
            _spinOnOff = false;
            buttonStopWheel = false;
        }
    }

    private List<Color> getDefaultColorList() {
        /*
		 * Returns default color list.
		 * To be used in case when no explicit color list is set.
         */
        List<Color> colors = new ArrayList<Color>();
        colors.add(Color.BLUE);
        colors.add(Color.CYAN);
        //colors.add(Color.DARK_GRAY);
        //colors.add(Color.GRAY);
        colors.add(Color.GREEN);
        //colors.add(Color.LIGHT_GRAY);
        colors.add(Color.MAGENTA);
        colors.add(Color.ORANGE);
        colors.add(Color.PINK);
        colors.add(Color.RED);
        colors.add(Color.WHITE);
        colors.add(Color.YELLOW);
        return colors;
    }
}
