/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wheelofjeopardy.config;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author alissachiu
 *
 * https://www.programiz.com/java-programming/objectoutputstream
 */
public class QuestionFileUtil {

    private static QuestionFileUtil INSTANCE = null;

    private final static String ROUND_1_DEFAULT_QUESTION_LIST = "defaultQuestionList.txt";
    private final static String CUSTOM_QUESTION_LIST_FILE = "customQuestionList.txt";

    private final static int NUM_CATEGORIES = 6;
    private final static int NUM_QUESTIONS_PER_CATEGORY = 5;
    private static final List<Category> categoryGroups = new ArrayList<>();
    private static final Category category1;
    private static final Category category2;
    private static final Category category3;
    private static final Category category4;
    private static final Category category5;
    private static final Category category6;

    // Initialize to use default questions
    static {
        category1 = new Category();
        category2 = new Category();
        category3 = new Category();
        category4 = new Category();
        category5 = new Category();
        category6 = new Category();
        // Category 1
        category1.setCategory("Chillin’ & Grillin’");
        category1.addQuestion(new JeopardyQuestion("Chillin’ & Grillin’",
                "The name of this flying creature describes slicing a slab of meat nearly in half and unfolding it flat.",
                "What is butterfly?",
                Arrays.asList("What is bird?", "What is pterodactyl?"),
                200));
        category1.addQuestion(new JeopardyQuestion("Chillin’ & Grillin’",
                "Manual ice cream machines require adding this condiment to the ice before churning the ingredients.",
                "What is salt?",
                Arrays.asList("What is mustard?", "What is pepper?"),
                400));
        category1.addQuestion(new JeopardyQuestion("Chillin’ & Grillin’",
                "This is the term for applying a seasoned liquid while grilling to keep the food soft and moist.",
                "What is basting?",
                Arrays.asList("What is fanning?", "What is smothering?"),
                600));
        category1.addQuestion(new JeopardyQuestion("Chillin’ & Grillin’",
                "This is the best time to apply barbecue sauce when grilling.",
                "What is toward the end of grilling?",
                Arrays.asList("What is at the beginning of grilling?", "What is two days prior to grilling?"),
                800));
        category1.addQuestion(new JeopardyQuestion("Chillin’ & Grillin’",
                "Salmon is often grilled on this type of wood plank to add flavor.",
                "What is cedar?",
                Arrays.asList("What is oak?", "What is birch?"),
                1000));
        // Category 2
        category2.setCategory("Familial Ties");
        category2.addQuestion(new JeopardyQuestion("Familial Ties",
                "Your spouse’s mother, father, sibling, or other relative by marriage.",
                "What is in-law?",
                Arrays.asList("What is niece?", "What is second cousin?"),
                200));
        category2.addQuestion(new JeopardyQuestion("Familial Ties",
                "Another term for people who share at least one parent.",
                "What is siblings?",
                Arrays.asList("What is cousins?", "What is roommate?"),
                400));
        category2.addQuestion(new JeopardyQuestion("Familial Ties",
                "This church maintains the largest free genealogy resource in the world.",
                "What is Church of Jesus Christ of Latter-Day Saints (or Mormon)?",
                Arrays.asList("What is Lakewood Church?", "What is North Point Ministries"),
                600));
        category2.addQuestion(new JeopardyQuestion("Familial Ties",
                "This term applies to cousins of different generations.",
                "What is once removed?",
                Arrays.asList("What is once added?", "What is once lost?"),
                800));
        category2.addQuestion(new JeopardyQuestion("Familial Ties",
                "Couples without a marriage license but who might share joint bank accounts, file joint tax returns, use the same last name, and have lived together for a number of years might be married under this in some states.",
                "What is common law?",
                Arrays.asList("What is ordinary law?", "What is exceptional law?"),
                1000));
        // Category 3
        category3.setCategory("Ologies");
        category3.addQuestion(new JeopardyQuestion("Ologies",
                "This is the study of animals.",
                "What is zoology?",
                Arrays.asList("What is anthrozoology?", "What is paleozoology?"),
                200));
        category3.addQuestion(new JeopardyQuestion("Ologies",
                "This science focuses on the relationship between living organisms and the environment.",
                "What is ecology?",
                Arrays.asList("What is enology?", "What is enigmatology?"),
                400));
        category3.addQuestion(new JeopardyQuestion("Ologies",
                "This is the study of earthquakes and other stresses within a planet.",
                "What is seismology?",
                Arrays.asList("What is sedimentology?", "What is semiology?"),
                600));
        category3.addQuestion(new JeopardyQuestion("Ologies",
                "If a scientist’s life’s work is the study of King Tut, this is their \"ology.\"",
                "What is Egyptology?",
                Arrays.asList("What is electrology?", "What is electrophysiology?"),
                800));
        category3.addQuestion(new JeopardyQuestion("Ologies",
                "This is the study of the causes and spread of diseases in a population.",
                "What is epidemiology?",
                Arrays.asList("What is enzymology?", "What is epileptology?"),
                1000));
        // Category 4
        category4.setCategory("Where’s the School?");
        category4.addQuestion(new JeopardyQuestion("Where’s the School?",
                "It is where you can find the University of Alabama’s main campus, home of the Crimson Tide.",
                "What is Tuscaloosa, Alabama?",
                Arrays.asList("What is Yampertown, Alabama?", "What is Hubbertville, Alabama?"),
                200));
        category4.addQuestion(new JeopardyQuestion("Where’s the School?",
                "University of Nebraska, home of the Cornhuskers, is in this capital city.",
                "What is Lincoln, Nebraska?",
                Arrays.asList("What is Pleasant Dale, Nebraska?", "What is Emerald, Nebraska?"),
                400));
        category4.addQuestion(new JeopardyQuestion("Where’s the School?",
                "It is home to the Volunteers of the University of Tennessee.",
                "What is Knoxville, Tennessee?",
                Arrays.asList("What is Chattanooga, Tennessee?", "What is Ooltewah, Tennessee?"),
                600));
        category4.addQuestion(new JeopardyQuestion("Where’s the School?",
                "Northwestern University, home of the Wildcats, is located near this large city.",
                "What is Chicago?",
                Arrays.asList("What is Boston?", "What is Miami?"),
                800));
        category4.addQuestion(new JeopardyQuestion("Where’s the School?",
                "This is where a prospective student could find the University of Georgia, home of the Bulldogs.",
                "What is Athens, Georgia?",
                Arrays.asList("What is Atlanta, Georgia?", "What is Augusta, Georgia?"),
                1000));
        // Category 5
        category5.setCategory("Simply Red");
        category5.addQuestion(new JeopardyQuestion("Simply Red",
                "This is rolled out to the airplane stairs when visiting foreign dignitaries arrive.",
                "What is red carpet?",
                Arrays.asList("What is red Maserati?", "What is red luggage carrier?"),
                200));
        category5.addQuestion(new JeopardyQuestion("Simply Red",
                "These red berries are a Thanksgiving favorite.",
                "What are cranberries?",
                Arrays.asList("What are strawberries?", "What are raspberries?"),
                400));
        category5.addQuestion(new JeopardyQuestion("Simply Red",
                "This adorable bug is red with black dots.",
                "What is ladybug?",
                Arrays.asList("What is berry bug?", "What is clover mite?"),
                600));
        category5.addQuestion(new JeopardyQuestion("Simply Red",
                "During this spectator event, the matador uses a red cape to cause the male bovine to charge.",
                "What is bullfighting?",
                Arrays.asList("What is cattlefighting?", "What is bullracing?"),
                800));
        category5.addQuestion(new JeopardyQuestion("Simply Red",
                "British soldiers were called this during the American Revolution.",
                "What are Redcoats?",
                Arrays.asList("What are Redboots?", "What are Redhats?"),
                1000));
        // Category 6
        category6.setCategory("Comfort Foods");
        category6.addQuestion(new JeopardyQuestion("Simply Red",
                "This city, nicknamed Bean Town, is named for baked beans made with molasses and salt pork.",
                "What is Boston?",
                Arrays.asList("What is Dallas?", "What is San Francisco?"),
                200));
        category6.addQuestion(new JeopardyQuestion("Simply Red",
                "This type of seafood roll is a favorite in Maine and Nova Scotia.",
                "What is lobster?",
                Arrays.asList("What is clam?", "What is crab?"),
                400));
        category6.addQuestion(new JeopardyQuestion("Simply Red",
                "Italians introduced this beef sandwich to Philadelphia in the 1930s.",
                "What is Philadelphia cheesesteak?",
                Arrays.asList("What is Philadelphia roast beef sandwich?", "What is Philadelphia Italian beef?"),
                600));
        category6.addQuestion(new JeopardyQuestion("Simply Red",
                "Traditional Canadian tart made with pastry shells and a filling of butter, sugar, and egg.",
                "What is butter tart?",
                Arrays.asList("What is sugar tart?", "What is egg tart?"),
                800));
        category6.addQuestion(new JeopardyQuestion("Simply Red",
                "The Canadian answer to America’s berry pies.",
                "What is Saskatoon berry pie?",
                Arrays.asList("What is Calgary berry pie?", "What is Vancouver berry pie?"),
                1000));

        categoryGroups.add(category1);
        categoryGroups.add(category2);
        categoryGroups.add(category3);
        categoryGroups.add(category4);
        categoryGroups.add(category5);
        categoryGroups.add(category6);
    }

    public static QuestionFileUtil getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new QuestionFileUtil();
        }
        return INSTANCE;
    }

    public List<Category> getCategoryGroups() {
        return categoryGroups;
    }

    public boolean loadCustomQuestionList() {
        //currQuestionList = new ArrayList<>();
        try {
            FileInputStream fileIn = new FileInputStream(CUSTOM_QUESTION_LIST_FILE);
            ObjectInputStream objIn = new ObjectInputStream(fileIn);
            int numObjects = objIn.readInt();
            for (int i = 0; i < numObjects; i++) {
                JeopardyQuestion question = (JeopardyQuestion) objIn.readObject();
                //currQuestionList.add(question);
            }
        } catch (Exception e) {
            System.out.println(Arrays.toString(e.getStackTrace()));
            return false;
        }

        return true;
    }

    public boolean writeCustomQuestionList(List<JeopardyQuestion> customQuestionList) {
        //currQuestionList = customQuestionList;
        // TODO: delete the CUSTOM_QUESTION_LIST_FILE if it already exists
        try {
            FileOutputStream fileOut = new FileOutputStream(CUSTOM_QUESTION_LIST_FILE);
            ObjectOutputStream objOut = new ObjectOutputStream(fileOut);
            objOut.write(customQuestionList.size());
            for (Category group : categoryGroups) {
                objOut.writeObject(group);
            }
        } catch (Exception e) {
            System.out.println(Arrays.toString(e.getStackTrace()));
            return false;
        }
        return true;
    }
}
