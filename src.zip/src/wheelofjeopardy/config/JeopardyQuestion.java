/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wheelofjeopardy.config;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alissachiu
 */
public class JeopardyQuestion implements Serializable {
    String category;
    String question;
    String correctAnswer;
    List<String> answersList;
    int value;
    
    public JeopardyQuestion() {
        question = new String();
        correctAnswer = new String();
        answersList = new ArrayList<>();
        value = 0;
    }
    
    public JeopardyQuestion(String category, String question, String correctAnswer, List<String> answersList, int value) {
        this.category = category;
        this.question = question;
        this.correctAnswer = correctAnswer;
        this.answersList = answersList;
        this.value = value;
    }
    
    public String getCategory() {
        return category;
    }
    
    public String getQuestion() {
        return question;
    }
    
    public String getCorrectAnswer() {
        return correctAnswer;
    }
    
    public List<String> getAnswersList() {
        return answersList;
    }
    
    public int getValue() {
        return value;
    }
    
    @Override
    public boolean equals(Object o) {

        if (o == this) return true;
        if (!(o instanceof JeopardyQuestion)) {
            return false;
        }

        JeopardyQuestion c = (JeopardyQuestion) o;

        return c.category.equals(category) &&
                c.question.equals(question) &&
                c.correctAnswer.equals(correctAnswer) &&
                c.answersList.equals(answersList) &&
                c.value == value;
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + category.hashCode();
        result = 31 * result + question.hashCode();
        result = 31 * result + correctAnswer.hashCode();
        result = 31 * result + answersList.hashCode();
        result = 31 * result + value;

        return result;
    }
}
