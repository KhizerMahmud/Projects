/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wheelofjeopardy.config;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alissachiu
 */
public class Category implements Serializable {
    String categoryName;
    List<JeopardyQuestion> questionList;
    
    public Category() {
        categoryName = new String();
        questionList = new ArrayList<>();
    }
    
    public Category(String categoryName, List<JeopardyQuestion> questionList) {
        this.categoryName = categoryName;
        this.questionList = questionList;
    }
    
    public String getCategory() {
        return categoryName;
    }
    
    public void setCategory(String categoryName) {
        this.categoryName = categoryName;
    }
    
    public void addQuestion(JeopardyQuestion question) {
        questionList.add(question);
    }
    
    public List<JeopardyQuestion> getQuestionList() {
        return questionList;
    }
}
