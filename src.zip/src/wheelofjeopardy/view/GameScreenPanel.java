/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package wheelofjeopardy.view;

import java.util.List;
import java.util.Observable;
import java.util.Observer;
import javax.swing.JLabel;
import wheelofjeopardy.model.GameModel;
import wheelofjeopardy.widgets.QuestionLabel;
import wheelofjeopardy.config.Category;

/**
 *
 * @author alissachiu
 */
public class GameScreenPanel extends javax.swing.JPanel {

    private transient final GameModel model = GameModel.getInstance();
            
    private static JLabel[] categoryLabels;
    private static QuestionLabel[] category1QuestionLabels;
    private static QuestionLabel[] category2QuestionLabels;
    private static QuestionLabel[] category3QuestionLabels;
    private static QuestionLabel[] category4QuestionLabels;
    private static QuestionLabel[] category5QuestionLabels;
    private static QuestionLabel[] category6QuestionLabels;
    private static List<Category> categoryGroups;
    
    private static boolean isSpinning = false;
    
    /**
     * Observes the model and updates the screen when the model data changes.
     */
    private transient Observer observer = new Observer() {
        @Override
        public void update(Observable o, Object arg) {
            updatePanel();
            //setVisible(true);
        }
    };
    
    /**
     * Creates new form MainMenuPanel
     */
    public GameScreenPanel() {
        initComponents();
        
        categoryGroups = model.getQuestions();
        
        model.addObserver(observer);
        
        // Category labels
        categoryLabels = new JLabel[]{category1Label, category2Label, category3Label,
            category4Label, category5Label, category6Label};
        // Category 1 question labels
        category1QuestionLabels = new QuestionLabel[]{questionLabel1, questionLabel2, questionLabel3, questionLabel4, questionLabel5};
        // Category 2 question labels
        category2QuestionLabels = new QuestionLabel[]{questionLabel6, questionLabel7, questionLabel8, questionLabel9, questionLabel10};
        // Category 3 question labels
        category3QuestionLabels = new QuestionLabel[]{questionLabel11, questionLabel12, questionLabel13, questionLabel14, questionLabel15};
        // Category 4 question labels
        category4QuestionLabels = new QuestionLabel[]{questionLabel16, questionLabel17, questionLabel18, questionLabel19, questionLabel20};
        // Category 5 question labels
        category5QuestionLabels = new QuestionLabel[]{questionLabel21, questionLabel22, questionLabel23, questionLabel24, questionLabel25};
        // Category 6 question labels
        category6QuestionLabels = new QuestionLabel[]{questionLabel26, questionLabel27, questionLabel28, questionLabel29, questionLabel30};

        setupCategoryLabels();
        setupQuestionLabels();
    }
    
    /*
    Called when the model data updates.
    */
    public void updatePanel() {
        updateBoardPanel();
        updateScorePanel();
    }
    
    private void updateBoardPanel() {
        // TODO
    }
    
    private void updateScorePanel() {
        // TODO
    }

    private void setupCategoryLabels() {
        for (int i = 0; i < categoryLabels.length; i++) {
            JLabel label = categoryLabels[i];
            label.setBackground(new java.awt.Color(7, 18, 119));
            label.setFont(new java.awt.Font("Arial Narrow", 1, 20));
            label.setForeground(new java.awt.Color(255, 255, 255));
            label.setOpaque(true);
            label.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
            label.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            label.setMaximumSize(new java.awt.Dimension(100, 70));
            label.setMinimumSize(new java.awt.Dimension(100, 70));
            label.setPreferredSize(new java.awt.Dimension(100, 70));
            // Use HTML to make the text wrap in label
            label.setText("<html><center>" + categoryGroups.get(i).getCategory() + "</center></html>");
        }
    }

    private void setupQuestionLabels() {
        for (int i = 0; i < category1QuestionLabels.length; i++) {
            // Set questions for labels
            category1QuestionLabels[i].setQuestion(categoryGroups.get(0).getQuestionList().get(i));
            category2QuestionLabels[i].setQuestion(categoryGroups.get(1).getQuestionList().get(i));
            category3QuestionLabels[i].setQuestion(categoryGroups.get(2).getQuestionList().get(i));
            category4QuestionLabels[i].setQuestion(categoryGroups.get(3).getQuestionList().get(i));
            category5QuestionLabels[i].setQuestion(categoryGroups.get(4).getQuestionList().get(i));
            category6QuestionLabels[i].setQuestion(categoryGroups.get(5).getQuestionList().get(i));
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        boardPanel = new javax.swing.JPanel();
        category1Label = new javax.swing.JLabel();
        category2Label = new javax.swing.JLabel();
        category3Label = new javax.swing.JLabel();
        category4Label = new javax.swing.JLabel();
        category5Label = new javax.swing.JLabel();
        category6Label = new javax.swing.JLabel();
        questionLabel1 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel2 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel3 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel4 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel5 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel6 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel7 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel8 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel9 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel10 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel11 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel12 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel13 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel14 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel15 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel16 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel17 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel18 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel19 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel20 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel21 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel22 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel23 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel24 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel25 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel26 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel27 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel28 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel29 = new wheelofjeopardy.widgets.QuestionLabel();
        questionLabel30 = new wheelofjeopardy.widgets.QuestionLabel();
        boardInstructionLabel = new javax.swing.JLabel();
        infoPanel = new javax.swing.JPanel();
        playerInfoPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        roundInfoPanel = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        wheelPanel = new javax.swing.JPanel();
        spinStopWheelButton = new javax.swing.JButton();
        wheel1 = new wheelofjeopardy.wheel.Wheel();
        wheelInstructionLabel = new javax.swing.JLabel();

        setBackground(new java.awt.Color(36, 54, 101));
        setLayout(new java.awt.BorderLayout());

        boardPanel.setBackground(new java.awt.Color(0, 0, 0));
        boardPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        boardPanel.setMinimumSize(new java.awt.Dimension(636, 410));
        boardPanel.setLayout(new java.awt.GridBagLayout());

        category1Label.setText("category1Label");
        category1Label.setOpaque(true);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 10, 3);
        boardPanel.add(category1Label, gridBagConstraints);

        category2Label.setText("category2Label");
        category2Label.setOpaque(true);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 10, 3);
        boardPanel.add(category2Label, gridBagConstraints);

        category3Label.setText("category3Label");
        category3Label.setOpaque(true);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 10, 3);
        boardPanel.add(category3Label, gridBagConstraints);

        category4Label.setText("category4Label");
        category4Label.setOpaque(true);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 10, 3);
        boardPanel.add(category4Label, gridBagConstraints);

        category5Label.setText("category5Label");
        category5Label.setOpaque(true);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 10, 3);
        boardPanel.add(category5Label, gridBagConstraints);

        category6Label.setText("category6Label");
        category6Label.setOpaque(true);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 5;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 10, 3);
        boardPanel.add(category6Label, gridBagConstraints);

        questionLabel1.setText("questionLabel1");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel1, gridBagConstraints);

        questionLabel2.setText("questionLabel2");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel2, gridBagConstraints);

        questionLabel3.setText("questionLabel3");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel3, gridBagConstraints);

        questionLabel4.setText("questionLabel4");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel4, gridBagConstraints);

        questionLabel5.setText("questionLabel5");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel5, gridBagConstraints);

        questionLabel6.setText("questionLabel6");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel6, gridBagConstraints);

        questionLabel7.setText("questionLabel7");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel7, gridBagConstraints);

        questionLabel8.setText("questionLabel8");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel8, gridBagConstraints);

        questionLabel9.setText("questionLabel9");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel9, gridBagConstraints);

        questionLabel10.setText("questionLabel10");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel10, gridBagConstraints);

        questionLabel11.setText("questionLabel11");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel11, gridBagConstraints);

        questionLabel12.setText("questionLabel12");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel12, gridBagConstraints);

        questionLabel13.setText("questionLabel13");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel13, gridBagConstraints);

        questionLabel14.setText("questionLabel14");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 4;
        boardPanel.add(questionLabel14, gridBagConstraints);

        questionLabel15.setText("questionLabel15");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel15, gridBagConstraints);

        questionLabel16.setText("questionLabel16");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel16, gridBagConstraints);

        questionLabel17.setText("questionLabel17");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel17, gridBagConstraints);

        questionLabel18.setText("questionLabel18");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel18, gridBagConstraints);

        questionLabel19.setText("questionLabel19");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel19, gridBagConstraints);

        questionLabel20.setText("questionLabel20");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel20, gridBagConstraints);

        questionLabel21.setText("questionLabel21");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel21, gridBagConstraints);

        questionLabel22.setText("questionLabel22");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel22, gridBagConstraints);

        questionLabel23.setText("questionLabel23");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel23, gridBagConstraints);

        questionLabel24.setText("questionLabel24");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel24, gridBagConstraints);

        questionLabel25.setText("questionLabel25");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel25, gridBagConstraints);

        questionLabel26.setText("questionLabel26");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 5;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel26, gridBagConstraints);

        questionLabel27.setText("questionLabel27");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 5;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel27, gridBagConstraints);

        questionLabel28.setText("questionLabel28");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 5;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel28, gridBagConstraints);

        questionLabel29.setText("questionLabel29");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 5;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel29, gridBagConstraints);

        questionLabel30.setText("questionLabel30");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 5;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 3, 3);
        boardPanel.add(questionLabel30, gridBagConstraints);

        boardInstructionLabel.setFont(new java.awt.Font("Helvetica Neue", 0, 24)); // NOI18N
        boardInstructionLabel.setForeground(new java.awt.Color(255, 255, 255));
        boardInstructionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        boardInstructionLabel.setText("Click the box to answer the next question");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.gridwidth = java.awt.GridBagConstraints.REMAINDER;
        gridBagConstraints.gridheight = java.awt.GridBagConstraints.REMAINDER;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        boardPanel.add(boardInstructionLabel, gridBagConstraints);

        add(boardPanel, java.awt.BorderLayout.EAST);

        infoPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        infoPanel.setLayout(new java.awt.GridBagLayout());

        playerInfoPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Player Info"));
        playerInfoPanel.setLayout(new java.awt.GridBagLayout());

        jLabel1.setText("Player Name");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        playerInfoPanel.add(jLabel1, gridBagConstraints);

        jLabel2.setText("Score");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        playerInfoPanel.add(jLabel2, gridBagConstraints);

        jLabel3.setText("Free Turn Tokens");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        playerInfoPanel.add(jLabel3, gridBagConstraints);

        jTextField1.setEditable(false);
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField1.setText("Player 1 Name");
        jTextField1.setMaximumSize(new java.awt.Dimension(125, 25));
        jTextField1.setMinimumSize(new java.awt.Dimension(125, 25));
        jTextField1.setPreferredSize(new java.awt.Dimension(125, 25));
        jTextField1.setRequestFocusEnabled(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        playerInfoPanel.add(jTextField1, gridBagConstraints);

        jLabel4.setText("1");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        playerInfoPanel.add(jLabel4, gridBagConstraints);

        jLabel5.setText("2");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        playerInfoPanel.add(jLabel5, gridBagConstraints);

        jLabel6.setText("3");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        playerInfoPanel.add(jLabel6, gridBagConstraints);

        jLabel7.setText("Player #");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        playerInfoPanel.add(jLabel7, gridBagConstraints);

        jTextField2.setEditable(false);
        jTextField2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField2.setText("0");
        jTextField2.setMaximumSize(new java.awt.Dimension(125, 25));
        jTextField2.setMinimumSize(new java.awt.Dimension(125, 25));
        jTextField2.setPreferredSize(new java.awt.Dimension(125, 25));
        jTextField2.setRequestFocusEnabled(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        playerInfoPanel.add(jTextField2, gridBagConstraints);

        jTextField3.setEditable(false);
        jTextField3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField3.setText("0");
        jTextField3.setMaximumSize(new java.awt.Dimension(125, 25));
        jTextField3.setMinimumSize(new java.awt.Dimension(125, 25));
        jTextField3.setPreferredSize(new java.awt.Dimension(125, 25));
        jTextField3.setRequestFocusEnabled(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        playerInfoPanel.add(jTextField3, gridBagConstraints);

        jTextField4.setEditable(false);
        jTextField4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField4.setText("Player 2 Name");
        jTextField4.setMaximumSize(new java.awt.Dimension(125, 25));
        jTextField4.setMinimumSize(new java.awt.Dimension(125, 25));
        jTextField4.setPreferredSize(new java.awt.Dimension(125, 25));
        jTextField4.setRequestFocusEnabled(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        playerInfoPanel.add(jTextField4, gridBagConstraints);

        jTextField5.setEditable(false);
        jTextField5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField5.setText("0");
        jTextField5.setMaximumSize(new java.awt.Dimension(125, 25));
        jTextField5.setMinimumSize(new java.awt.Dimension(125, 25));
        jTextField5.setPreferredSize(new java.awt.Dimension(125, 25));
        jTextField5.setRequestFocusEnabled(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        playerInfoPanel.add(jTextField5, gridBagConstraints);

        jTextField6.setEditable(false);
        jTextField6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField6.setText("0");
        jTextField6.setMaximumSize(new java.awt.Dimension(125, 25));
        jTextField6.setMinimumSize(new java.awt.Dimension(125, 25));
        jTextField6.setPreferredSize(new java.awt.Dimension(125, 25));
        jTextField6.setRequestFocusEnabled(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        playerInfoPanel.add(jTextField6, gridBagConstraints);

        jTextField7.setEditable(false);
        jTextField7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField7.setText("Player 3 Name");
        jTextField7.setMaximumSize(new java.awt.Dimension(125, 25));
        jTextField7.setMinimumSize(new java.awt.Dimension(125, 25));
        jTextField7.setPreferredSize(new java.awt.Dimension(125, 25));
        jTextField7.setRequestFocusEnabled(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        playerInfoPanel.add(jTextField7, gridBagConstraints);

        jTextField8.setEditable(false);
        jTextField8.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField8.setText("0");
        jTextField8.setMaximumSize(new java.awt.Dimension(125, 25));
        jTextField8.setMinimumSize(new java.awt.Dimension(125, 25));
        jTextField8.setPreferredSize(new java.awt.Dimension(125, 25));
        jTextField8.setRequestFocusEnabled(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        playerInfoPanel.add(jTextField8, gridBagConstraints);

        jTextField9.setEditable(false);
        jTextField9.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField9.setText("0");
        jTextField9.setMaximumSize(new java.awt.Dimension(125, 25));
        jTextField9.setMinimumSize(new java.awt.Dimension(125, 25));
        jTextField9.setPreferredSize(new java.awt.Dimension(125, 25));
        jTextField9.setRequestFocusEnabled(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        playerInfoPanel.add(jTextField9, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        infoPanel.add(playerInfoPanel, gridBagConstraints);

        roundInfoPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Round Info"));
        roundInfoPanel.setLayout(new java.awt.GridBagLayout());

        jLabel8.setText("Current Player Turn:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        roundInfoPanel.add(jLabel8, gridBagConstraints);

        jLabel9.setText("Number of Spins Remaining:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        roundInfoPanel.add(jLabel9, gridBagConstraints);

        jLabel10.setText("Round Number:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        roundInfoPanel.add(jLabel10, gridBagConstraints);

        jTextField10.setEditable(false);
        jTextField10.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField10.setText("Player 1 Name");
        jTextField10.setMaximumSize(new java.awt.Dimension(125, 25));
        jTextField10.setMinimumSize(new java.awt.Dimension(125, 25));
        jTextField10.setPreferredSize(new java.awt.Dimension(125, 25));
        jTextField10.setRequestFocusEnabled(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        roundInfoPanel.add(jTextField10, gridBagConstraints);

        jTextField11.setEditable(false);
        jTextField11.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField11.setText("50");
        jTextField11.setMaximumSize(new java.awt.Dimension(125, 25));
        jTextField11.setMinimumSize(new java.awt.Dimension(125, 25));
        jTextField11.setPreferredSize(new java.awt.Dimension(125, 25));
        jTextField11.setRequestFocusEnabled(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        roundInfoPanel.add(jTextField11, gridBagConstraints);

        jTextField12.setEditable(false);
        jTextField12.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField12.setText("1");
        jTextField12.setMaximumSize(new java.awt.Dimension(125, 25));
        jTextField12.setMinimumSize(new java.awt.Dimension(125, 25));
        jTextField12.setPreferredSize(new java.awt.Dimension(125, 25));
        jTextField12.setRequestFocusEnabled(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.insets = new java.awt.Insets(4, 4, 4, 4);
        roundInfoPanel.add(jTextField12, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        infoPanel.add(roundInfoPanel, gridBagConstraints);

        add(infoPanel, java.awt.BorderLayout.SOUTH);

        wheelPanel.setLayout(new java.awt.BorderLayout());

        spinStopWheelButton.setText("Spin the Wheel");
        spinStopWheelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                spinStopWheelButtonActionPerformed(evt);
            }
        });
        wheelPanel.add(spinStopWheelButton, java.awt.BorderLayout.NORTH);

        javax.swing.GroupLayout wheel1Layout = new javax.swing.GroupLayout(wheel1);
        wheel1.setLayout(wheel1Layout);
        wheel1Layout.setHorizontalGroup(
            wheel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 632, Short.MAX_VALUE)
        );
        wheel1Layout.setVerticalGroup(
            wheel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 696, Short.MAX_VALUE)
        );

        wheelPanel.add(wheel1, java.awt.BorderLayout.CENTER);

        wheelInstructionLabel.setBackground(new java.awt.Color(0, 0, 0));
        wheelInstructionLabel.setFont(new java.awt.Font("Helvetica Neue", 0, 24)); // NOI18N
        wheelInstructionLabel.setForeground(new java.awt.Color(255, 255, 255));
        wheelInstructionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        wheelInstructionLabel.setText("Category is: Chillin' & Grillin'");
        wheelInstructionLabel.setOpaque(true);
        wheelPanel.add(wheelInstructionLabel, java.awt.BorderLayout.SOUTH);

        add(wheelPanel, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void spinStopWheelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_spinStopWheelButtonActionPerformed
        if (!isSpinning) {
            isSpinning = true;
            wheel1.startSpinning();
            spinStopWheelButton.setText("Stop Spinning");
        } else {
            isSpinning = false;
            wheel1.stopSpinning();
            spinStopWheelButton.setText("Spin the Wheel");
            // TODO: disable the button until the wheel stops spinning/the next question is answered
        }
    }//GEN-LAST:event_spinStopWheelButtonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel boardInstructionLabel;
    private javax.swing.JPanel boardPanel;
    private javax.swing.JLabel category1Label;
    private javax.swing.JLabel category2Label;
    private javax.swing.JLabel category3Label;
    private javax.swing.JLabel category4Label;
    private javax.swing.JLabel category5Label;
    private javax.swing.JLabel category6Label;
    private javax.swing.JPanel infoPanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JPanel playerInfoPanel;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel1;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel10;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel11;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel12;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel13;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel14;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel15;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel16;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel17;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel18;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel19;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel2;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel20;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel21;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel22;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel23;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel24;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel25;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel26;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel27;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel28;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel29;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel3;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel30;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel4;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel5;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel6;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel7;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel8;
    private wheelofjeopardy.widgets.QuestionLabel questionLabel9;
    private javax.swing.JPanel roundInfoPanel;
    private javax.swing.JButton spinStopWheelButton;
    private wheelofjeopardy.wheel.Wheel wheel1;
    private javax.swing.JLabel wheelInstructionLabel;
    private javax.swing.JPanel wheelPanel;
    // End of variables declaration//GEN-END:variables
}
